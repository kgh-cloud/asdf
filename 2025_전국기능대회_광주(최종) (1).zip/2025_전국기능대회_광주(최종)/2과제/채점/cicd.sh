echo -e "========1-1-========"
echo "배포 타입 확인"
TASK_DEF_ARN=$(aws ecs describe-services \
  --cluster Gwangju-cicd-cluster \
  --services Gwangju-cicd-service \
  --query "services[0].taskDefinition" \
  --output text)
aws ecs describe-task-definition \
  --task-definition "$TASK_DEF_ARN" \
  --query "taskDefinition.requiresCompatibilities" \
  --output json

read -p "작업 수행 후 채점, Commit 후 엔터를 입력하여 실행"

aws elbv2 describe-load-balancers --names Gwangju-cicd-alb --query 'LoadBalancers[0].DNSName' --output text | xargs -I {} bash -c 'for i in {1..6}; do curl -s -o /dev/null -w "%{http_code}\n" http://{}/health; sleep 10; done' | grep -c '^200$'

echo -e "\n========1-2-========"
read -p "작업 수행 후 채점, 엔터를 입력하여 실행"

TASK_DEF_ARN=$(aws ecs describe-services \
  --cluster Gwangju-cicd-cluster \
  --services Gwangju-cicd-service \
  --query "services[0].taskDefinition" \
  --output text)
aws ecs describe-task-definition \
  --task-definition "$TASK_DEF_ARN" \
  --query "taskDefinition.requiresCompatibilities" \
  --output json

echo -e "\n========1-3-========"
aws elbv2 describe-load-balancers --names Gwangju-cicd-alb --query "LoadBalancers[0].DNSName" --output text

echo -e "\n========1-4-========"
read -p "작업 수행 후 채점, Commit 후 엔터를 입력하여 실행"

aws elbv2 describe-load-balancers --names Gwangju-cicd-alb --query 'LoadBalancers[0].DNSName' --output text | xargs -I {} bash -c 'for i in {1..6}; do curl -s -o /dev/null -w "%{http_code}\n" http://{}/health; sleep 10; done' | grep -c '^200$'

echo -e "\n========1-5-========"
read -p "작업 수행 후 채점, 엔터를 입력하여 실행"

TASK_DEF_ARN=$(aws ecs describe-services \
  --cluster Gwangju-cicd-cluster \
  --services Gwangju-cicd-service \
  --query "services[0].taskDefinition" \
  --output text)
aws ecs describe-task-definition \
  --task-definition "$TASK_DEF_ARN" \
  --query "taskDefinition.requiresCompatibilities" \
  --output json

aws elbv2 describe-load-balancers --names Gwangju-cicd-alb --query "LoadBalancers[0].DNSName" --output text