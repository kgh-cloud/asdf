#!/bin/bash

echo =====1-1=====
aws ecs describe-services   --cluster gwangju-logging-cluster   --services gwangju-logging-svc   --query "services[].launchType"   --output text
echo

echo =====1-2=====
aws ecs describe-task-definition --task-definition gwangju-logging-ecs-td \
    --query "taskDefinition.containerDefinitions[].image" \
    --output text | tr '\t' '\n'
echo

echo =====1-3=====
TASK_ARNs=$(aws ecs list-tasks --cluster gwangju-logging-cluster --desired-status RUNNING --output text --query 'taskArns[]')
aws ecs describe-tasks --cluster gwangju-logging-cluster --tasks $TASK_ARNs \
  --query 'tasks[].containers[].{ContainerName:name, Status:lastStatus}' \
  --output text
echo

echo =====1-4=====
aws logs filter-log-events \
  --log-group-name /gwangju-logging/cloudwatch \
  --filter-pattern ERROR \
  --query 'events[].message' \
  --output text | while read -r line; do
    echo "$line" | jq -r .
done | grep -E 'INFO|DEBUG|WARNING|CRITICAL'
echo

echo =====1-5=====
aws logs filter-log-events \
  --log-group-name /gwangju-logging/cloudwatch \
  --filter-pattern ERROR \
  --query 'events[].message' \
  --output text | while read -r line; do
    echo "$line" | jq -r .
done | grep ERROR
echo