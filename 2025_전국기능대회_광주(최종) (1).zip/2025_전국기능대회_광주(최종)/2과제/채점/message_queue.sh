KEY="/home/ec2-user/Gwangju.pem"
IP=$(aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=Gwangju-queue-ec2" \
           "Name=instance-state-name,Values=running" \
  --query "Reservations[*].Instances[*].PublicIpAddress" \
  --output text)


echo -e "========1-1-========"
echo "기존 log stream 삭제"
aws logs delete-log-stream \
  --log-group-name Gwangju-queue-log-group \
  --log-stream-name $(aws logs describe-log-streams \
    --log-group-name Gwangju-queue-log-group \
    --order-by LastEventTime \
    --descending \
    --query 'logStreams[0].logStreamName' \
    --output text)
echo "message-app.py 해시값 검증"
EXPECTED_HASH="dc7421320fc7f85dd3b1c0392bcda188431f6f765d4b3c0ba909c4c192005dd4"
ACTUAL_HASH=$(sha256sum message-app.py | awk '{print $1}')
[ "$ACTUAL_HASH" = "$EXPECTED_HASH" ] \
  && echo "해시값이 일치합니다." \
  || echo "해시값이 일치하지 않습니다."
echo "message-app.py 실행"
python3 message-app.py
sleep 10
echo "SQS 대기열 메시지 수 확인"
QUEUE_URL=$(aws sqs list-queues \
  --queue-name-prefix Gwangju-queue \
  --region ap-southeast-1 \
  --query 'QueueUrls[0]' \
  --output text)
aws sqs get-queue-attributes \
  --queue-url "$QUEUE_URL" \
  --attribute-names ApproximateNumberOfMessages \
  --region ap-southeast-1

echo -e "\n========1-2-========"
echo "Gwangju-queue-ec2에 ssh로 접속합니다"
sudo chmod 400 Gwangju.pem
ssh -i "$KEY" -o StrictHostKeyChecking=no ec2-user@"$IP" << 'EOF'
python3 worker.py
sleep 10
aws sqs get-queue-attributes --queue-url \
"$(aws sqs list-queues --queue-name-prefix Gwangju-queue --region ap-southeast-1 --query 'QueueUrls[0]' --output text)" \
--attribute-names ApproximateNumberOfMessages \
--region ap-southeast-1
exit
EOF

echo -e "\n========1-3-========"
echo "최근 3개의 CloudWatch 로그 출력"
aws logs get-log-events \
  --log-group-name Gwangju-queue-log-group \
  --log-stream-name $(aws logs describe-log-streams \
    --log-group-name Gwangju-queue-log-group \
    --order-by LastEventTime \
    --descending \
    --query 'logStreams[0].logStreamName' \
    --output text) \
  --limit 3

echo -e "\n========1-4-========"
echo "CloudWatch 로그 그룹의 메트릭 필터 출력"
aws logs describe-metric-filters \
  --log-group-name "Gwangju-queue-log-group"

echo -e "\n========1-5-========"
echo "콘솔 채점"