#!/bin/bash

echo =====0-0=====
aws ec2 run-instances \
  --region us-east-1 \
  --image-id ami-00ca32bbc84273381 \
  --instance-type t3.micro \
  --count 1 \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=gwangju-instance-1},{Key=Project,Value=gwangju}]' \
  --no-cli-pager
aws iam list-attached-role-policies   --role-name gwangju-governance-instance-profile-1   --query 'AttachedPolicies[*].{PolicyName:PolicyName, PolicyArn:PolicyArn}'   --output text
aws iam list-attached-role-policies   --role-name gwangju-governance-instance-profile-2   --query 'AttachedPolicies[*].{PolicyName:PolicyName, PolicyArn:PolicyArn}'   --output text
sleep 120
echo

echo =====1-1=====
INSTANCE_ID=$(aws ec2 describe-instances \
    --filters "Name=tag:Name,Values=gwangju-instance-1" "Name=instance-state-name,Values=running" \
    --query "Reservations[].Instances[].InstanceId" --output text)
aws ec2 associate-iam-instance-profile \
    --instance-id $INSTANCE_ID \
    --iam-instance-profile Name=gwangju-governance-instance-profile-1
sleep 180
aws iam list-attached-role-policies \
  --role-name $(aws iam get-instance-profile --instance-profile-name gwangju-governance-instance-profile-1 --query 'InstanceProfile.Roles[0].RoleName' --output text) \
  --query 'AttachedPolicies[*].{PolicyName:PolicyName, PolicyArn:PolicyArn}' \
  --output text
echo

echo =====1-2=====
LOG_STREAM_NAME=$(aws logs describe-log-streams \
  --log-group-name "/gwangju/governance/cloudwatch" \
  --order-by LastEventTime \
  --descending \
  --limit 1 \
  --query "logStreams[0].logStreamName" \
  --output text)
aws logs get-log-events \
  --log-group-name "/gwangju/governance/cloudwatch" \
  --log-stream-name "$LOG_STREAM_NAME" \
  --limit 100 \
  --query "events[*].message" \
  --output text | tr '\t' '\n' | grep -oE "(Attached|Detached) policy: .*"
echo

echo =====1-3=====
INSTANCE_ID=$(aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=gwangju-instance-1" "Name=instance-state-name,Values=running" \
  --query "Reservations[].Instances[].InstanceId" --output text)
ASSOCIATION_ID=$(aws ec2 describe-iam-instance-profile-associations \
  --filters Name=instance-id,Values=$INSTANCE_ID \
  --query 'IamInstanceProfileAssociations[?State==`associated`].AssociationId' \
  --output text)
aws ec2 disassociate-iam-instance-profile --association-id $ASSOCIATION_ID
aws ec2 associate-iam-instance-profile \
  --instance-id $INSTANCE_ID \
  --iam-instance-profile Name=gwangju-governance-instance-profile-2
sleep 180
aws iam list-attached-role-policies \
  --role-name $(aws iam get-instance-profile --instance-profile-name gwangju-governance-instance-profile-2 --query 'InstanceProfile.Roles[0].RoleName' --output text) \
  --query 'AttachedPolicies[*].{PolicyName:PolicyName, PolicyArn:PolicyArn}' \
  --output text
echo

echo =====1-4=====
LOG_STREAM_NAME=$(aws logs describe-log-streams \
  --log-group-name "/gwangju/governance/cloudwatch" \
  --order-by LastEventTime \
  --descending \
  --limit 1 \
  --query "logStreams[0].logStreamName" \
  --output text)
aws logs get-log-events \
  --log-group-name "/gwangju/governance/cloudwatch" \
  --log-stream-name "$LOG_STREAM_NAME" \
  --limit 100 \
  --query "events[*].message" \
  --output text | tr '\t' '\n' | grep -iE "attached policy:|detached policy:|no policies attached"
echo

echo =====1-5=====
INSTANCE_ID=$(aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=gwangju-instance-1" "Name=instance-state-name,Values=running" \
  --query "Reservations[0].Instances[0].InstanceId" \
  --output text)
aws configservice get-compliance-details-by-resource \
  --resource-type AWS::EC2::Instance \
  --resource-id $INSTANCE_ID \
  --query "EvaluationResults[*].ComplianceType" \
  --output text
echo