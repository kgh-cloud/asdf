import asyncio
import aiohttp
import time
import boto3
import requests
from botocore.exceptions import ClientError

# 설정
LAMBDA_FUNCTION_NAME = "Gwangju-queue-lambda"  # Lambda 함수 이름
TOTAL_REQUESTS = 20000
CONCURRENCY = 200
BATCH_SIZE = 200

# 리전 자동 감지 (EC2 인스턴스 메타데이터 활용)
def get_region_from_metadata():
    try:
        response = requests.get(
            "http://169.254.169.254/latest/dynamic/instance-identity/document",
            timeout=1
        )
        return response.json().get("region")
    except Exception as e:
        raise RuntimeError(f"리전 메타데이터 조회 실패: {e}")

# 세션 및 클라이언트 생성
AWS_REGION = get_region_from_metadata()
session = boto3.session.Session(region_name=AWS_REGION)
lambda_client = session.client("lambda")

# Lambda Function URL 가져오기
def get_lambda_function_url():
    try:
        response = lambda_client.get_function_url_config(FunctionName=LAMBDA_FUNCTION_NAME)
        return response["FunctionUrl"]
    except ClientError as e:
        print(f"[Lambda URL 가져오기 실패] {e}")
        return None

# Lambda로 비동기 POST 요청 보내기
async def send_post(session, i, target_url):
    data = {"message": f"Hello from request {i}"}
    headers = {"Content-Type": "application/json"}

    try:
        async with session.post(target_url, json=data, headers=headers) as response:
            if response.status == 200:
                return True
            else:
                print(f"요청 {i} 실패: 상태 코드 {response.status}")
                return False
    except Exception as e:
        print(f"요청 {i} 예외 발생: {e}")
        return False
    finally:
        await asyncio.sleep(0.005)  # 요청 간 딜레이

# 메인 비동기 루프
async def main():
    target_url = get_lambda_function_url()
    if not target_url:
        print("❌ Lambda Function URL을 가져올 수 없습니다.")
        return

    connector = aiohttp.TCPConnector(limit=CONCURRENCY)
    timeout = aiohttp.ClientTimeout(total=60)
    success_count = 0

    async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
        for batch_start in range(0, TOTAL_REQUESTS, BATCH_SIZE):
            batch_end = min(batch_start + BATCH_SIZE, TOTAL_REQUESTS)
            tasks = [send_post(session, i, target_url) for i in range(batch_start, batch_end)]
            results = await asyncio.gather(*tasks)
            batch_success = results.count(True)
            success_count += batch_success
            print(f"{batch_start} ~ {batch_end} 요청 중 성공: {batch_success}")
            await asyncio.sleep(1)  # 배치 간 짧은 대기

    print(f"총 성공 요청 수: {success_count} / {TOTAL_REQUESTS}")

# 실행
if __name__ == "__main__":
    start = time.time()
    asyncio.run(main())
    print(f"총 소요 시간: {time.time() - start:.2f}초")
