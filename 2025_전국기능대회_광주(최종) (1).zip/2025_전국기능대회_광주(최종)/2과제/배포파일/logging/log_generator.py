#!/usr/bin/env python3

import time
import json
import random
from datetime import datetime

LOG_LEVELS = ["INFO", "DEBUG", "WARNING", "ERROR", "CRITICAL"]

MESSAGES = {
    "INFO": "Service started successfully.",
    "DEBUG": "Debugging variable state.",
    "WARNING": "Memory usage nearing limit.",
    "ERROR": "Unable to connect to database.",
    "CRITICAL": "System failure! Immediate action required."
}

def generate_token():
    return ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=16))

def generate_log():
    while True:
        log_level = random.choice(LOG_LEVELS)
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "log_level": log_level,
            "message": MESSAGES[log_level]
        }

        if log_level == "ERROR":
            log_entry["token"] = generate_token()

        print(json.dumps(log_entry))
        time.sleep(random.uniform(0.5, 2.0))

if __name__ == "__main__":
    generate_log()
